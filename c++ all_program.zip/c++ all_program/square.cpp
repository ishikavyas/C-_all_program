#include<iostream>
using namespace std;

int main()
{
    int i;
    cout<<"This is Output\n";
    
    cout<<"Enter a number: ";
    cin>>i;
    
    cout<<i<<" Square is "<<i*i<< "\n";
    return 0;
